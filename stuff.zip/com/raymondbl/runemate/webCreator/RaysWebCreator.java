package com.raymondbl.runemate.webCreator;

import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.runemate.game.api.client.paint.PaintListener;
import com.runemate.game.api.hybrid.entities.GameObject;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.entities.details.Locatable;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.location.navigation.web.Web;
import com.runemate.game.api.hybrid.location.navigation.web.WebVertex;
import com.runemate.game.api.hybrid.location.navigation.web.default_webs.FileWeb;
import com.runemate.game.api.hybrid.location.navigation.web.vertex_types.CoordinateVertex;
import com.runemate.game.api.hybrid.queries.GameObjectQueryBuilder;
import com.runemate.game.api.hybrid.region.GameObjects;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.hybrid.util.StopWatch;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.LoopingScript;

public class RaysWebCreator extends LoopingScript implements
								PaintListener, ActionListener
{
	private boolean condition;
	private Coordinate position;
	private RaysWebCreatorGUI gui;
	private Player player;
	private String command;
	private Web web = new Web();
	private Map<Coordinate, WebVertex> vertices = new HashMap<>();
	private StopWatch runtime = new StopWatch();
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		String command = e.getActionCommand();
		if(command.equals("addArea") || command.equals("gen"))
		{
			this.command = command;
			condition = true;
		}
	}

	@Override
	public void onPaint(Graphics2D g) 
	{
		if(gui != null)
		gui.setRuntime(runtime.getRuntimeAsString());
	}

	@Override
	public void onStart(String... args)
	{
		getEventDispatcher().addListener(this);
		gui = new RaysWebCreatorGUI();
		player = Players.getLocal();
		gui.setVisible(true);
		runtime.start();
		gui.setListener(this);
	}
	
	@Override
	public void onLoop() 
	{
		condition = false;
		System.out.println("Waiting...");
		gui.setStatus("Waiting...");
		Execution.delayUntil(() -> condition);
		if(command.equals("addArea"))
		{
			addCoordinate(getSurroundingWeb(player, 20, 2).toArray(new Coordinate[] {}));
		}
		if(command.equals("gen"))
			make();
		if(command.equals("reset"))
			reset();
			
	}
	
	public void make()
	{
		FileWeb web = new FileWeb();
		web.addVertices(this.web.getVertices());
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("webbset.web")))
		{
			oos.writeObject(web.toByteArray());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	 public static List<Coordinate> getSurroundingWeb(final Locatable loc, final int radius, final int divisibleBy) {
	        final Coordinate[] reachable = loc.getPosition().getReachableCoordinates().toArray(new Coordinate[] {});
	        List<Coordinate> web = new ArrayList<Coordinate>();
	        for (Coordinate c : reachable) {
	            if (c.getX() % divisibleBy == 0 && c.getY() % divisibleBy == 0 && c.distanceTo(loc) <= radius) {
	                web.add(c);
	            }
	        }
	        return web;
	    }
	 
	    public void addCoordinate(Coordinate... coordinates) {
	        final GameObjectQueryBuilder objects = GameObjects.newQuery().types(GameObject.Type.BOUNDARY_OBJECT, GameObject.Type.PRIMARY, GameObject.Type.WALL_DECORATION);
	        for (Coordinate c : coordinates) {
	            final CoordinateVertex cv = new CoordinateVertex(c);
	            web.addVertices(cv);
	            final int[][] add = new int[][]{{-2, +2}, {0, +2}, {+2, +2}, {+2, 0}, {+2, -2}, {0, -2}, {-2, -2}, {-2, 0}};
	            for (int[] i : add) {
	                final Coordinate yes = new Coordinate(c.getX() + i[0], c.getY() + i[1], c.getPlane());
	                final Coordinate between = new Coordinate(c.getX() + i[0] / 2, c.getY() + i[1] / 2, c.getPlane());
	                final WebVertex v = getVertexAt(yes);
	                if (v != null && objects.on(between).results().isEmpty()) {
	                    cv.addBidirectionalEdge(v);
	                }
	            }
	        }
	    }
	 
	    WebVertex getVertexAt(Coordinate coordinate) {
	        for (WebVertex v : web.getRegularVertices()) {
	            if (v.getPosition().equals(coordinate)) {
	                return v;
	            }
	        }
	        return null;
	    }
	
	public void addArea()
	{
		int radius = getRadius();
		position = player.getPosition();
		Collection<Coordinate> collection = position.getReachableCoordinates();
		Iterator<Coordinate> iterator = collection.iterator();
		while(iterator.hasNext())
		{
			Coordinate c = iterator.next();
			if(c.distanceTo(player) <= radius)
			{
				GameObject object = GameObjects.getLoadedAt(c).first();
				if((object == null) || !object.getDefinition().impassable())
				{
					CoordinateVertex v = new CoordinateVertex(c);
					vertices.put(c, v);
				}
			}
		}
		
		vertices.forEach((Coordinate key, WebVertex vertex) -> 
		{
			int[][] ar = new int[][]
					{
					{-1, 0, 1}, {-1, 0, 1}
					};
			for(int i = 0; i < 3; i++)
			{
				for(int k = 0; k < 3; k++)
				{
					Coordinate c = new Coordinate(ar[0][i], ar[1][k]);
					if(vertices.containsKey(c))
					{
						vertex.addBidirectionalEdge(vertices.get(c));
					}
				}
			}
		});		
	}
	
	public void gen()
	{
		gui.setStatus("genning...");
		System.out.println("genning...");
		Collection<WebVertex> list = new ArrayList<>();
		vertices.forEach((Coordinate key, WebVertex vertex) -> 
				list.add(vertex));
		FileWeb web = new FileWeb();
		web.addVertices(list);
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("webbie.web")))
		{
			oos.writeObject(web.toByteArray());
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

	public void reset()
	{
		vertices = new HashMap<>();
	}
	
	public int getRadius()
	{
		return Integer.parseInt(gui.getRadius());
	}
	
}

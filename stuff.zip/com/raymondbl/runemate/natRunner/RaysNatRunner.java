package com.raymondbl.runemate.natRunner;

import java.awt.Graphics2D;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.runemate.game.api.client.paint.PaintListener;
import com.runemate.game.api.hybrid.entities.GameObject;
import com.runemate.game.api.hybrid.entities.Player;
import com.runemate.game.api.hybrid.entities.details.Locatable;
import com.runemate.game.api.hybrid.input.Keyboard;
import com.runemate.game.api.hybrid.local.Camera;
import com.runemate.game.api.hybrid.local.hud.interfaces.Bank;
import com.runemate.game.api.hybrid.local.hud.interfaces.Equipment;
import com.runemate.game.api.hybrid.local.hud.interfaces.InterfaceComponent;
import com.runemate.game.api.hybrid.local.hud.interfaces.Interfaces;
import com.runemate.game.api.hybrid.local.hud.interfaces.Inventory;
import com.runemate.game.api.hybrid.local.hud.interfaces.SpriteItem;
import com.runemate.game.api.hybrid.location.Area;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.location.navigation.Traversal;
import com.runemate.game.api.hybrid.location.navigation.basic.PredefinedPath;
import com.runemate.game.api.hybrid.location.navigation.cognizant.RegionPath;
import com.runemate.game.api.hybrid.location.navigation.web.Web;
import com.runemate.game.api.hybrid.location.navigation.web.WebVertex;
import com.runemate.game.api.hybrid.location.navigation.web.default_webs.FileWeb;
import com.runemate.game.api.hybrid.location.navigation.web.vertex_types.CoordinateVertex;
import com.runemate.game.api.hybrid.queries.GameObjectQueryBuilder;
import com.runemate.game.api.hybrid.region.GameObjects;
import com.runemate.game.api.hybrid.region.Players;
import com.runemate.game.api.hybrid.util.Filter;
import com.runemate.game.api.hybrid.util.StopWatch;
import com.runemate.game.api.hybrid.util.calculations.Random;
import com.runemate.game.api.rs3.local.hud.interfaces.eoc.ActionBar;
import com.runemate.game.api.rs3.local.hud.interfaces.eoc.SlotAction;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.LoopingScript;
import com.runemate.game.api.script.framework.listeners.InventoryListener;
import com.runemate.game.api.script.framework.listeners.events.ItemEvent;

public class RaysNatRunner extends LoopingScript implements
									PaintListener, InventoryListener
{
	private StopWatch runtime = new StopWatch();
	private boolean condition;
	private boolean npcContact;
	private boolean repairPouch;
	private int natsAdded;
	private int natsRemoved;
	private int essAdded;
	private int i;
	private int essRemoved;
	private Player player;
	private List<Coordinate> list;
	private Web web = Traversal.getDefaultWeb();
	

    public boolean merge(final File file) {
    	try(ObjectInputStream input = new ObjectInputStream(new FileInputStream(file)))
    	{
            Object obj = input.readObject();
            if(obj != null && obj instanceof byte[])
            {
            	System.out.println("Is an instance of");
            	FileWeb fileWeb = FileWeb.fromByteArray((byte[])obj);
            	System.out.println(fileWeb.getVertices());
            	this.web.addVertices(fileWeb.getVertices());
            }
            else System.out.println("not an instance of");
        } catch (Exception e) {
            e.printStackTrace();
        }
    	return true;
    }
    
	@Override
	public void onStart(String... args)
	{
		setLoopDelay(200, 400);
		getEventDispatcher().addListener(this);
		runtime.start();
		player = Players.getLocal();
		merge(new File("webbset.web"));
	}
	
	@Override
	public void onPaint(Graphics2D g) 
	{
		
	}
	
	@Override
	public void onItemAdded(ItemEvent event)
	{
		condition = true;
		essRemoved = 0;
	}
	
	@Override
	public void onItemRemoved(ItemEvent event)
	{
		essRemoved += event.getQuantityChange();	
	}
	@Override
	public void onLoop() 
	{
		System.out.println(web.getPathBuilder().buildTo(Data.OBELISK));
		stop();
	}
	
	public boolean refill()
	{
		Execution.delayUntil(() -> openBank());
		Execution.delayUntil(() -> depositNatureRunes());
		Execution.delayUntil(() -> checkPouches());
		Execution.delayUntil(() -> checkRing());
		Execution.delayUntil(() -> checkFamiliar());
		Execution.delayUntil(() -> withdrawAll(Data.ESS_FILTER));
		Execution.delayUntil(() -> fillPouches());
		Execution.delayUntil(() -> closeBank());
		return true;
	}
	
	public boolean openBank()
	{
		if(!Bank.isOpen())
		{
			Execution.delayUntil(() -> 
			{	Bank.open();
				return Bank.isOpen();
			});
		}
		return true;
	}
	
	public boolean closeBank()
	{
		if(Bank.isOpen())
		{
			Execution.delayUntil(() -> 
			{
				Bank.close();
				return !Bank.isOpen();
			});
		}
		return true;
	}
	
	public boolean depositNatureRunes()
	{
		if(Inventory.contains(Data.NATURE_RUNE_ID))
		{
			Execution.delayUntil(() -> 
			{
			Bank.depositAllExcept(Data.POUCHES_FILTER);
			return !Inventory.contains(Data.NATURE_RUNE_ID);
			});
		}
		return true;
	}
	
	public boolean checkPouches()
	{
		if(Inventory.containsAnyOf(Data.DEGR_POUCHES_FILTER))
		{
			if(npcContact)
				repairNPC();
		}
		return true;
	}
	
	public boolean repairNPC()
	{
		if(Bank.containsAllOf(Data.ASTRAL_RUNE_ID, Data.COSMIC_RUNE_ID))
		{
			Execution.delayUntil(() -> 
			{
				Bank.withdraw(Data.ASTRAL_RUNE_ID, 1);
				return Inventory.contains(Data.ASTRAL_RUNE_ID);
			});
			Execution.delayUntil(() -> 
			{
				Bank.withdraw(Data.COSMIC_RUNE_ID, 1);
				return Inventory.contains(Data.COSMIC_RUNE_ID);
			});
			SlotAction slotAction = ActionBar.getFirstAction(Data.NPC_CONTACT);
			Execution.delayUntil(() -> slotAction.activate());
			Execution.delayUntil(() -> Interfaces.getAt(88, 6, 14)!= null);
			Execution.delayUntil(() -> Interfaces.getAt(88, 6, 14).isVisible());
			Execution.delayUntil(() -> Interfaces.getAt(88, 6, 14).click());
			for(int i = 0; i <= 2; i++)
			{
				Execution.delayUntil(() -> interfaceNext(1191, 7));
				Execution.delayUntil(() -> interfaceNext(1184, 11));
			}
			Execution.delayUntil(() -> interfaceNext(1188, 18));
			Execution.delayUntil(() -> interfaceNext(1184, 11));
		}
		return true;
	}
	
	public boolean interfaceNext(int i, int k)
	{
		Execution.delayUntil(() -> Interfaces.getAt(i, k) != null);
		Execution.delayUntil(() -> Interfaces.getAt(i, k).isVisible());
		Execution.delayUntil(() -> Interfaces.getAt(i, k).click());
		return true;
	}
	
	public boolean checkRing()
	{
		if(!Equipment.containsAnyOf(Data.RING_ARRAY))
		{
			Execution.delayUntil(() -> 
			{
				Bank.withdraw(Data.RING_FILTER, 1);
				return Inventory.containsAnyOf(Data.RING_FILTER);
			});
			
			Execution.delayUntil(() -> 
			{
				Inventory.getItems(Data.RING_FILTER).first().interact("Wear");
				return Equipment.containsAnyOf(Data.RING_ARRAY);
			});
		}
		return true;
	}
	
	public boolean checkFamiliar()
	{
		if(player.getFamiliar() == null)
		{
			Execution.delayUntil(() -> 
			{
				Bank.withdraw(Data.GRAAHK_POUCH_ID, 1);
				return Inventory.contains(Data.GRAAHK_POUCH_ID);
			});
			closeBank();
			Execution.delayUntil(() -> 
			{
				Inventory.newQuery().filter(Data.GRAAHK_POUCH_FILTER).results().first().interact("Summon");
				return player.getFamiliar() != null;
			});
			openBank();
		}
		return true;
	}
	
	public boolean withdrawAll(Filter<SpriteItem> filter)
	{
		SpriteItem item = Bank.getFirstItem(filter);
		Execution.delayUntil(() -> item.interact("Withdraw-All"));
		return true;
	}
	
	public boolean fillPouches()
	{
		for(Pouch pouch : Data.POUCHES_ARRAY)
		{
			int pouchId = pouch.getId();
			int pouchCapacity = pouch.getCapacity();
			if(Inventory.contains(pouchId))
			{
				if(Inventory.getQuantity(Data.PURE_ESS) <= pouchCapacity)
				{
					Execution.delayUntil(() -> 
					{
						withdrawAll(Data.ESS_FILTER);
						return (Inventory.getQuantity(Data.PURE_ESS) >= pouchCapacity
								&& Bank.containsAnyOf(Data.PURE_ESS));
					});
				}
				if(Inventory.getQuantity(Data.PURE_ESS) >= pouchCapacity)
				{
					Execution.delayUntil(() ->
					{
						Inventory.newQuery().filter(new Filter<SpriteItem>()
								{
							@Override
							public boolean accepts(SpriteItem s)
							{
								return s.getId() == pouchId;
							}
								}).results().first().interact("Fill");
						return essRemoved == pouchCapacity;
					}, 256, 512);
					essRemoved = 0;
				}
			}
		}
		return true;
	}
	
	public boolean walkToAltar()
	{
		Execution.delayUntil(() -> player.getFamiliar().interact("Interact"));
		Execution.delayUntil(() -> interfaceNext(1188, 18));
		Execution.delayUntil(() -> player.distanceTo(Data.RUINS) <= 100);
		if(true);
		Execution.delayUntil(() -> Traversal.getDefaultWeb().getPathBuilder().buildTo(Data.RUINS).step(true));
		return true;
	}

}

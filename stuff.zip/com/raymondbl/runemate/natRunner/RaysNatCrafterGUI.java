package com.raymondbl.runemate.natRunner;

import com.raymondbl.runemate.utilities.GUI;

@SuppressWarnings("serial")
public class RaysNatCrafterGUI extends GUI
{
	
	@Override
	protected void initComponents() 
	{
		
	}

}

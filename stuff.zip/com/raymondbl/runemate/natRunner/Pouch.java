package com.raymondbl.runemate.natRunner;

public class Pouch {

	private int id;
	private int capacity;
	
	public Pouch(int id, int capacity)
	{
		this.id = id;
		this.capacity = capacity;
	}
	
	public int getId()
	{
		return id;
	}
	
	public int getCapacity()
	{
		return capacity;
	}
}

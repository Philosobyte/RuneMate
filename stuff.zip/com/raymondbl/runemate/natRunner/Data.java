package com.raymondbl.runemate.natRunner;

import com.runemate.game.api.hybrid.local.hud.interfaces.SpriteItem;
import com.runemate.game.api.hybrid.location.Coordinate;
import com.runemate.game.api.hybrid.util.Filter;

public final class Data {

	static final int NATURE_RUNE_ID = 561;
	static final int COSMIC_RUNE_ID = 564;
	static final int ASTRAL_RUNE_ID = 9075;
	static final int PURE_ESS = 7936;
	static final Pouch SMALL_POUCH = new Pouch(5509, 3);
	static final Pouch MEDIUM_POUCH = new Pouch (5510, 6);
	static final Pouch LARGE_POUCH = new Pouch(5512, 9);
	static final Pouch GIANT_POUCH = new Pouch(5514, 12);
	static final Pouch MASSIVE_POUCH = new Pouch(24204, 18);
	static final Pouch DEGR_MEDIUM_POUCH = new Pouch(5511, 5);
	static final Pouch DEGR_LARGE_POUCH = new Pouch(5513, 7);
	static final Pouch DEGR_GIANT_POUCH = new Pouch(5515, 9);
	static final Pouch[] POUCHES_ARRAY = {SMALL_POUCH, MEDIUM_POUCH,
		LARGE_POUCH, GIANT_POUCH, MASSIVE_POUCH, DEGR_MEDIUM_POUCH, 
		DEGR_LARGE_POUCH, DEGR_GIANT_POUCH};
	static final Filter<SpriteItem> POUCHES_FILTER = new Filter<SpriteItem>()
			{
				@Override
				public boolean accepts(SpriteItem spriteItem) 
				{
					int id = spriteItem.getId();
					for(Pouch pouch : POUCHES_ARRAY)
					{
						if(id == pouch.getId())
						{
							return true;
						}
					}
					return false;
				}
			};
			
	static final Pouch[] DEGR_POUCHES = {DEGR_MEDIUM_POUCH, 
		DEGR_LARGE_POUCH, DEGR_GIANT_POUCH};
	static final Filter<SpriteItem> DEGR_POUCHES_FILTER = new Filter<SpriteItem>()
			{

				@Override
				public boolean accepts(SpriteItem item) 
				{	int itemId = item.getId();
					for(Pouch pouch : DEGR_POUCHES)
					{
						if(itemId == pouch.getId())
							return true;
					}
					return false;
				}
		
			};
	static final Filter<SpriteItem> ESS_FILTER = new Filter<SpriteItem>()
			{
				@Override
				public boolean accepts(SpriteItem spriteItem)
				{
					return spriteItem.getId() == PURE_ESS;
				}
			};
	static final Coordinate OBELISK = new Coordinate(2851, 3027, 0);
	static final Coordinate RUINS = new Coordinate(2869, 3019, 0);
	static final Coordinate ALTAR = new Coordinate(2400, 4841, 0);
	
	String obeliskPosition = "2851, 3027, 0";
	int obeliskID = 29938;
	String obeliskAction = "Renew points";
	
	String mysteriousRuinsPosition = "2869, 3019, 0";
	int mysteriousRuinsID = 2460;
	String mysteriousRuinsAction = "Enter";
	
	String altarPosition = "2400, 4841, 0";
	int altarID = 2486;
	String altarAction = "Craft-rune";

	static final int RING_8 = 2552;
	static final int RING_7 = 2554;
	static final int RING_6 = 2556;
	static final int RING_5 = 2558;
	static final int RING_4 = 2560;
	static final int RING_3 = 2562;
	static final int RING_2 = 2564;
	static final int RING_1 = 2566;
	static final int[] RING_ARRAY = {RING_8, RING_7, RING_6,
		RING_5, RING_4, RING_3, RING_2, RING_1};
	static final Filter<SpriteItem> RING_FILTER = new Filter<SpriteItem>()
			{

				@Override
				public boolean accepts(SpriteItem spriteItem) 
				{
					for(int i : RING_ARRAY)
					{
						if(spriteItem.getId() == i)
							return true;
					}
					return false;
				}
				
			};
			
	static final int GRAAHK_POUCH_ID = 12810;
	static final Filter<SpriteItem> GRAAHK_POUCH_FILTER = new Filter<SpriteItem>()
			{
				@Override
				public boolean accepts(SpriteItem spriteItem)
				{
					return spriteItem.getId() == GRAAHK_POUCH_ID;
				}
			};
	int CastleWars = 529;
	
	String bankChestPosition = "2447, 3084, 0";
	int bankChestID = 83634;
	String bankChestAction = "Use";
	
	static final int bankInterfaceContainer = 762;
	static final int banksInventoryInterfaceContainer = 7;
	
	int spiritGraahkID = 7363;
	String spiritGraahkAction = "Interact";
	int[] interfaceComponentTeleport = {1188, 18};
	
	
	int maxYaw = 292;
	int minYaw = 242;
	
	static final int NPC_CONTACT = 1734;
	int repairRunePouchID = 1926;
	int[] darkMageInterfaceComponent = {88, 6, 14};
	
	String c1 = "Hello?";
	int interfaceContainerChat1 = 1191;
	int[] i1 = {1191, 7};
	
	String c2 = "What is this?! You must not break my concentration!";
	int[] i2 = {1184, 11};
	
	String c3 = "It's";
	int[] i3 = i1;
	
	String c4 = "Are you";
	int[] i4 = i2;
	
	String c5 = "Sorry to disturb";
	int[] i5 = i1;
	
	String c6 = "What?";
	int[] i6 = i2;
	
	String c7 = "Can you repair";
	int[] i7 = {1188, 18};
	
	String c8 = "A simple transfiguration";
	int[] i8 = i2;
	
	
	
	
	
}

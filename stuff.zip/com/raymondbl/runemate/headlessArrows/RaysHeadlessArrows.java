/** Ray's Headless Arrows
 * @author Raymondbl
 * @version 0.50
 * 12/22/2014
 */
package com.raymondbl.runemate.headlessArrows;

import java.awt.Graphics2D;
import java.util.concurrent.TimeUnit;

import com.runemate.game.api.client.paint.PaintListener;
import com.runemate.game.api.hybrid.input.Keyboard;
import com.runemate.game.api.hybrid.local.Skill;
import com.runemate.game.api.hybrid.local.hud.interfaces.InterfaceComponent;
import com.runemate.game.api.hybrid.local.hud.interfaces.Interfaces;
import com.runemate.game.api.hybrid.local.hud.interfaces.Inventory;
import com.runemate.game.api.hybrid.local.hud.interfaces.SpriteItem;
import com.runemate.game.api.hybrid.util.StopWatch;
import com.runemate.game.api.hybrid.util.calculations.CommonMath;
import com.runemate.game.api.hybrid.util.calculations.Random;
import com.runemate.game.api.script.Execution;
import com.runemate.game.api.script.framework.LoopingScript;
import com.runemate.game.api.script.framework.listeners.InventoryListener;
import com.runemate.game.api.script.framework.listeners.SkillListener;
import com.runemate.game.api.script.framework.listeners.events.ItemEvent;
import com.runemate.game.api.script.framework.listeners.events.SkillEvent;

public class RaysHeadlessArrows extends LoopingScript implements  
								PaintListener, InventoryListener, SkillListener
{
	private RaysHeadlessArrowsGUI gui;
	private StopWatch runtime = new StopWatch();
	private InterfaceComponent popup;
	private SpriteItem arrowShafts;
	private SpriteItem feathers;
	private int headlessArrows;
	private int expGain;
	private int count;
	private static final int ARROW_SHAFT_ID = 52;
	private static final int FEATHER_ID = 314;
	private static final int HEADLESS_ARROW_ID = 53;
	
	@Override
	public void onStart(String... args)
	{
		getEventDispatcher().addListener(this);
		gui = new RaysHeadlessArrowsGUI();
		gui.setVisible(true);
		gui.setStatus("initializing...");
		runtime.start();
		getSpriteItems();
		setLoopDelay(200, 400);
		Execution.delayUntil(() -> (arrowShafts != null) && (feathers != null));
		arrowShafts.hover();
		feathers.hover();
	}
	
	@Override
	public void onLoop() 
	{
		clickSpriteItems();
		Execution.delayUntil(() -> popup.isVisible(), 1000, 2000);
		pressSpace();
	}
	
	public void clickSpriteItems()
	{	gui.setStatus("Clicking...");
		getSpriteItems();
		if(Inventory.getSelectedItem() != null)
		{
			Inventory.getSelectedItem().click();
		}
		if(arrowShafts.click())
		{
			if(feathers.click())
			{
				getPopup();
			}
			else clickSpriteItems();
			
		}
		else clickSpriteItems();
		arrowShafts.hover();
	}
	
	@Override
	public void onPause()
	{
		runtime.stop();
	}
	
	@Override
	public void onResume()
	{
		runtime.start();
		getSpriteItems();
	}
	
	public void getSpriteItems()
	{
		if(Inventory.containsAllOf(ARROW_SHAFT_ID, FEATHER_ID))
		{
			arrowShafts = Inventory.getItems(ARROW_SHAFT_ID).first();
			feathers = Inventory.getItems(FEATHER_ID).first();
		}
		else 
			{
			gui.setStatus("Out of resources");
			Execution.delay(1000);
			stop();
			}
		
	}
	
	public void getPopup()
	{
		Execution.delayUntil(() -> Interfaces.getAt(1370, 38) != null);
		popup = Interfaces.getAt(1370, 38);
	}
	
	public void pressSpace()
	{
		Keyboard.typeKey(" ");
		gui.setStatus("Waiting...");
		Execution.delayUntil(() -> count == 10, 15000);
		if(Random.nextDouble(0, 1) > 0.998)
		{
			Execution.delay((long)Random.nextGaussian(20700, 97830, 42740));		
		}
		resetCount();
	}
	
	public void resetCount()
	{
		count = 0;
	}
	
	@Override
	public void onItemAdded(ItemEvent event)
	{
		if(event.getItem().getId() == HEADLESS_ARROW_ID)
		{
			headlessArrows += event.getQuantityChange();
			if(gui != null)
			gui.setHeadlessArrows(headlessArrows);
			count++;
		}
	}
	
	@Override
	public void onExperienceGained(SkillEvent event)
	{
		if(event.getType().equals(SkillEvent.Type.EXPERIENCE_GAINED) && 
				event.getSkill().equals(Skill.FLETCHING))
		expGain += event.getChange();
		if(gui != null)
		gui.setExp(expGain);
	}
	
	@Override
	public void onPaint(Graphics2D arg0) 
	{
		if(gui != null)
		{
		gui.setRunTime(runtime.getRuntimeAsString());
		gui.setHeadlessArrowsPerHr((int)CommonMath.rate(TimeUnit.HOURS, runtime.getRuntime(), headlessArrows));
		gui.setExpPerHr((int)CommonMath.rate(TimeUnit.HOURS, runtime.getRuntime(), expGain));
		}
	}
}
